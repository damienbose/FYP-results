We see that the search algorithms do improve; however, there is a persitene for break deletion. This is an issue because break deletion seems to consitently compile; however, this should not be our decidting criteria.

Options:
- Over values compilation and run success in fitness. Maybe multiply reward by some constant c < 1. (Does this make sense?)
- Delete BreakDeletion as an arm
- Try the caching stuff

Note: ReturnDeletiong had the best fitness for random search. 